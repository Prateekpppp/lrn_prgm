<?php
    require 'users.php';
    // echo "test";
    // getUsers();
    $users=getUsers();
// echo $users;
// echo getUsers();
    include 'partials/header.php';
?>


    <div class="container">
        <p>testing</p>
    <table class="table">
        <thead>
            <tr>
                <th>id</th>
                <th>name</th>
                <th>website</th>
                <th>action</th>
            </tr>
            
        </thead>
        <tbody>
            <?php foreach ($users as $user); ?>
            <tr>
                <td><?php  echo $user['id'] ?></td>
                <td><?php  echo $user['name'] ?></td>
                <td><a target="blank" href="https://<?php  echo $user['website'] ?>"><?php  echo $user['website'] ?></a></td>
                <td>
                    <a href="view.php?id=<?php  echo $user['id'] ?>" class="btn btn-outline-info">View</a>
                    <a href="update.php?id=<?php  echo $user['id'] ?>" class="btn btn-outline-secondary">Update</a>
                    <a href="delete.php?id=<?php  echo $user['id'] ?>" class="btn btn-outline-danger">Delete</a>
                </td>
            </tr>
            
        </tbody>
        
    </table>
    </div>
<?php
    include 'partials/footer.php';
?>
