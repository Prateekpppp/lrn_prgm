<?php
    require "users.php";
       $userID = $_GET['id'];
       $user = getUserById($userID);
    if(!isset($_GET['id'])){
        // echo 'not found';
        include 'partials/not_found.php';
        exit;
    }
    if (!$user){
        // echo 'not found';
        include 'partials/not_found.php';
        exit;
    }
        
    
    //$userID = $_GET['id'];
   // echo $userId;
    //  print_r($user);
    // var_dump($_SERVER);
        
    include 'partials/header.php';
if ($_SERVER["REQUEST_METHOD"]==="POST"){
     echo '<pre>';
    // updateUser($_POST);
    var_dump($_POST);
     echo '</pre>';
}
  
?>
<div class="container">
    <h3 style="text-align:center;"><?php  echo $user[name]; ?></h3>
    <form method="POST" enctype="multipart/form-data" action="">
    <div class="form-group">
        <label>Name</label>
        <input name="name" value="<?php echo $user["name"];?>" class="form-control">
        <label>website</label>
        <input name="website" value="<?php echo $user["website"];?>" class="form-control">
        <label>image</label>
        <input name="image" type="file" class="form-control-file">
        
    </div>
    <button class="btn btn-success">Submit</button>
</form>
</div>

<?php
    include 'partials/footer.php';
?>