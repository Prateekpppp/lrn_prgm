<?php 
include 'header.php';
?>
<div class="alert alert-danger">User not found</div>
<?php
include 'footer.php';
?>