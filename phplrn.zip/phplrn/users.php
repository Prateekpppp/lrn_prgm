<?php
function getUsers(){
    // $users=json_decode(file_get_contents("users.json"), true);
    // echo '<pre>';
    // var_dump($users);
    // echo '<pre>';
    // exit;
    // or we can right
    return json_decode(file_get_contents("users.json"),true) ;

}
function getUserById($id){
    $users = getUsers();
    foreach ($users as $user){
        if ($user['id'] == $id){
            return $user ;
        }
    }
}
function createUser($data){

}
function updateUser($data, $id){

}
function deleteUser($id){

}


?>